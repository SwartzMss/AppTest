#include <sys/time.h>
#define TIMED 1
#include "tst-cond20.c"
