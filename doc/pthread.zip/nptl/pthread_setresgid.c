#define SINGLE_THREAD
#define __setresgid pthread_setresgid_np
#include <setresgid.c>
