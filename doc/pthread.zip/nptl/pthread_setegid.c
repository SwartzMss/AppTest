#define SINGLE_THREAD
#define setegid pthread_setegid_np
#include <setegid.c>
