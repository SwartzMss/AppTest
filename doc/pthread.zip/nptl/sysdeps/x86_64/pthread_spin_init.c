#include "../i386/pthread_spin_init.c"
