/* pthread_spin_init is in pthread_spin_unlock.S */
