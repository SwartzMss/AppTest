#define NEW_VERNUM GLIBC_2_6
#include <nptl/pthread_attr_setstack.c>
